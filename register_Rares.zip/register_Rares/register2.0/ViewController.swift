//
//  ViewController.swift
//  register2.0
//
//  Created by Boza Rares-Dorian on 19/02/2018.
//  Copyright © 2018 Boza Rares-Dorian. All rights reserved.
//

import UIKit

class ViewController: UIViewController {


    @IBOutlet weak var namefield: UITextField!
    @IBOutlet weak var mailfield: UITextField!
    @IBOutlet weak var passwordfield: UITextField!
    //am incercat sa vad daca stiu sa fac cu getter si setter
    
    static let nameTag = 1
    static let emailTag = 2
    static let passwordTag = 3
    
    var email_value: String {
        get {
            return String(mailfield.text!)!
            
        }
        set {
            mailfield.text = "\(newValue)"
        }
    }
    
    
    @IBOutlet weak var show_result: UILabel!
    
    //asta este functia de eliminat keyboard-ul pe care am inteles-o numai ca inca mai am dubii cu #selector(ViewController.dismissKeyboard)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        namefield.delegate = self
        passwordfield.delegate = self
        mailfield.delegate = self
        let tap: UITapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(ViewController.dismissKeyboard))
        view.addGestureRecognizer(tap)
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }
    
    
   let charset = NSCharacterSet(charactersIn: "@.")
    
    @IBAction func register_button(_ sender: UIButton) {
    if namefield.text?.isEmpty == false && mailfield.text?.isEmpty == false && passwordfield.text?.isEmpty == false
    { if email_value.rangeOfCharacter(from: charset as CharacterSet) != nil
    {
    
        if (passwordfield.text?.characters.count)! >= 6
        {show_result.text = "Inregistrare reusita"
            show_result.textColor = UIColor.green}
        ///invalid password
        else
        {
            show_result.text = "Parola invalida"
            show_result.textColor = UIColor.red
        }
        
        
        
        }///invalid email address
        else
    { show_result.text = "E-Mail Invalid"
        show_result.textColor = UIColor.red
        
        
        }
        
        }
    ///uncompleted fields warning
        else
    {
        show_result.text = "Nu ati completat toate campurile"
        show_result.textColor = UIColor.red
        }
    }
 
   
    
}


extension ViewController: UITextFieldDelegate {
    
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField.tag == ViewController.nameTag {
            if textField.text?.characters.count == 0 {
                print("Scrie ceva in nameField!")
            } else {
                textField.resignFirstResponder()
                mailfield.becomeFirstResponder()
            }
            
        } else {
            if textField.tag == ViewController.emailTag {
                textField.resignFirstResponder()
                passwordfield.becomeFirstResponder()
                
            } else {
                textField.resignFirstResponder()
            }
        }
        return true
    }
}
